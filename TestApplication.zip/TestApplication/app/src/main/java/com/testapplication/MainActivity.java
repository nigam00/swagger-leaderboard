package com.example.daksharekha.testapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView name, userid, rank;
    ImageView pic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ApiCall fetchPlaceData = new ApiCall();
        fetchPlaceData.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        name = (TextView) findViewById(R.id.txt_name);
        userid = (TextView) findViewById(R.id.txt_userid);
        rank = (TextView) findViewById(R.id.txt_rank);
        pic = (ImageView) findViewById(R.id.img_pic);
    }

    class ApiCall extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... strings) {
            try {
                URL url = new URL("https://us-central1-cratso-171712.cloudfunctions.net/cratso_internship/leaderboard?pointer=10&offset=5");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    return stringBuilder.toString();
                }
                finally{
                    urlConnection.disconnect();
                }
            }
            catch(Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(String apiResponses) {
            super.onPostExecute(apiResponses);
            Log.d("Response", apiResponses);
            Gson gson = new Gson();
            APIResponse response = gson.fromJson( apiResponses, APIResponse.class );
            showFirstData(response);
        }
    }

    private void showFirstData(APIResponse response) {
        name.setText(response.getData().get(0).getName());
        userid.setText(response.getData().get(0).getUserId());
        rank.setText(response.getData().get(0).getRank() + "");
        // use picasso to load image with url
        //use recycler view to show list
    }
}

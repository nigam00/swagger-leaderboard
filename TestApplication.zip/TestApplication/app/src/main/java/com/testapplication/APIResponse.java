package com.example.daksharekha.testapplication;

import java.util.List;

/**
 * Created by daksharekha on 7/28/17.
 */

public class APIResponse {
    private MetaData metadata;
    private List<DBUser> data;

    public MetaData getMetadata() {
        return metadata;
    }

    public void setMetadata(MetaData metadata) {
        this.metadata = metadata;
    }

    public List<DBUser> getData() {
        return data;
    }

    @Override
    public String toString() {
        return "APIResponse{" +
                "metadata=" + metadata +
                ", data=" + data +
                '}';
    }

    public void setData(List<DBUser> data) {
        this.data = data;
    }

    public class MetaData{
        private boolean lastEntry;
        private int pointer;

        public boolean isLastEntry() {
            return lastEntry;
        }

        public void setLastEntry(boolean lastEntry) {
            this.lastEntry = lastEntry;
        }

        public int getPointer() {
            return pointer;
        }

        public void setPointer(int pointer) {
            this.pointer = pointer;
        }

        @Override
        public String toString() {
            return "MetaData{" +
                    "lastEntry=" + lastEntry +
                    ", pointer=" + pointer +
                    '}';
        }
    }

    public class DBUser{
        private String name;
        private String user_id;
        private String profile_pic;
        private int rank;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUserId() {
            return user_id;
        }

        public void setUserId(String userId) {
            this.user_id = userId;
        }

        public String getProfilePic() {
            return profile_pic;
        }

        public void setProfilePic(String profilePic) {
            this.profile_pic = profilePic;
        }

        public int getRank() {
            return rank;
        }

        public void setRank(int rank) {
            this.rank = rank;
        }

        @Override
        public String toString() {
            return "DBUser{" +
                    "name='" + name + '\'' +
                    ", userId='" + user_id + '\'' +
                    ", profilePic='" + profile_pic + '\'' +
                    ", rank=" + rank +
                    '}';
        }
    }
}
